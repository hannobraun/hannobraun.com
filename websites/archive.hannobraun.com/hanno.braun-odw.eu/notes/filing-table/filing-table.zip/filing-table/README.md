# Filing Table

## About

These are the OpenSCAD models for my filing table. See [article](https://madeby.hannobraun.de/project/filing-table) for more information.

## License

Copyright (c) 2020 Hanno Braun <hb@hannobraun.de>

Everything in this archive is licensed under the terms of the [Zero-Clause BSD License] (0BSD). See LICENSE.md for details.

[Zero-Clause BSD License](https://opensource.org/licenses/0BSD)

